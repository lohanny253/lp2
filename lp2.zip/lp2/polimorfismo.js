class Animal {
    fazerSom() {
        console.log("O animal faz um som");
    }
}

class Cachorro extends Animal {
    fazerSom() {
        console.log("O cachorro late: Au Au!");
    }
}

class Gato extends Animal {
    fazerSom() {
        console.log("O gato mia: Miau!");
    }
}
function emitirSom(animal) {
    animal.fazerSom();
}

const meuCachorro = new Cachorro();
const meuGato = new Gato();

emitirSom(meuCachorro); 
emitirSom(meuGato);    
