const carro = {
    marca: 'Fusca',
    ano: 1975,
    cor: 'azul',
    
    info: function() {
        return `${this.marca} - ${this.ano} - ${this.cor}`;
    }
};

console.log('Marca do carro:', carro.marca);
console.log('Ano do carro:', carro.ano);
console.log('Cor do carro:', carro.cor);

carro.cor = 'vermelho';
console.log('Nova cor do carro:', carro.cor);

console.log('Informações do carro:', carro.info());
