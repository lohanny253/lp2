const carro = {
    marca: 'Toyota',
    modelo: 'Corolla',
    ano: 2020,
    cor: 'preto',
    
    mostrarInfo: function() {
        return `${this.marca} ${this.modelo}, ${this.ano}, ${this.cor}`;
    }
};

console.log(carro.marca); 
console.log(carro.modelo); 

console.log(carro.mostrarInfo()); 
 