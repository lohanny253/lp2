class Carro {
    
    constructor(marca, modelo, ano) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
    }

    exibirInfo() {
        return `${this.marca} ${this.modelo} - ${this.ano}`;
    }
}

const meuCarro = new Carro('Toyota', 'Corolla', 2020);

console.log(meuCarro.exibirInfo()); 
