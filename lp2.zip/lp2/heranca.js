
class Animal {
    constructor(nome) {
        this.nome = nome;
    }

    falar() {
        console.log(`${this.nome} faz barulho.`);
    }
}

class Cachorro extends Animal {
    falar() {
        console.log(`${this.nome} late.`);
    }
}

const meuCachorro = new Cachorro('Rex');
meuCachorro.falar(); 
